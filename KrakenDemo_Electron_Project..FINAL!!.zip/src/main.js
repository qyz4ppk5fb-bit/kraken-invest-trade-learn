const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow () {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// Simple IPC for demo trades (no real network)
ipcMain.handle('mock-get-balance', async () => {
  return { usd: 10000.00, btc: 0.5 };
});

ipcMain.handle('mock-place-order', async (event, order) => {
  // very simple simulated response
  return { success: true, orderId: 'ORD' + Math.floor(Math.random()*1000000) };
});
