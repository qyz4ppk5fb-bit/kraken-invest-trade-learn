const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getBalance: () => ipcRenderer.invoke('mock-get-balance'),
  placeOrder: (order) => ipcRenderer.invoke('mock-place-order', order)
});
